Features:

Customizable Messages
Advanced config
Counting game
	Unlimited Channels
	Auto Pin Messages
	Role Rewards
	Close Channel On Max Number
Animated Games
Anti Cheat Detection
Hooks into Corebot's Experience System
Hooks into Corebot's Coin System
Coin Rewards

Commands:

BlackJack - Play a game of blackjack.
Blacklist - Blacklist a user from playing all games.
Horsey - Play a game of horse racing.
Roulette - Play a game of roulette.
RussianRoulette - Play a game of Russian roulette with your friends.
Rjoin - Join your friends game of RussianRoulette.
Trivia - Play a game of trivia.
TypingTest - Play a game where you type out a sentence and calculate your words per minute.